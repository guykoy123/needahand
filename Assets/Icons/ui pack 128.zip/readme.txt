Iconset: Core - UI - Outlined (https://www.iconfinder.com/iconsets/core-ui-outlined)
Author: Kit of Parts (https://www.iconfinder.com/kitofparts)
License: Free for commercial use ()
Download date: 2022-01-06